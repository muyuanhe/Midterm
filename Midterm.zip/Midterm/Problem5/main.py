import math as m
import numpy as np
import matplotlib.pyplot as plt
import scipy.linalg as LA
import csv
import sys
from sympy import symbols, diff # use these two lib to make partial derivatives
from scipy.fft import fft, ifft
from time import process_time
from scipy.linalg import logm, expm

# part c
def U(r1, r2, r3):
    return None
T = 50
dt = 0.1 #time step
tol = 10e-4

def F(X): # X = [r1, v1, r2, v2, r3, v3]
    r1 = X[0]
    v1 = X[1]
    r2 = X[2]
    v2 = X[3]
    r3 = X[4]
    v3 = X[5]

    a1 = (-1) * (r1-r2)/np.power(np.linalg.norm(r1-r2),3) - (r1-r3)/np.power(np.linalg.norm(r1-r3),3)
    a2 = (-1) * (r2-r1)/np.power(np.linalg.norm(r1-r2),3) - (r2-r3)/np.power(np.linalg.norm(r2-r3),3)
    a3 = (-1) * (r3-r1)/np.power(np.linalg.norm(r1-r3),3) - (r3-r2)/np.power(np.linalg.norm(r2-r3),3)

    fx = [v1, a1, v2, a2, v3, a3]
    fx = np.asarray(fx)
    return fx

def RK4(X0, n): # X0 is in the form of [r1, v1, r2, v2, r3, v3] ; n is number of iterations
    X_list = []
    X_list.append(X0)
    for i in range(n):

        h = 50/n

        F1 = h * F(X0)
        F2 = h * F(X0 + 0.5*h*F1)
        F3 = h * F(X0 + 0.5*h*F2)
        F4 = h * F(X0 + h*F3)
        x_next = X0 + h*(F1 + 2*F2 + 2*F3 + F4) / 6
        X0 = x_next
        X_list.append(x_next)
    X_list = np.asarray(X_list)
    return X_list


X0 = [[0, 0],[0, 0],[0, 1],[1, 0],[0, -1],[-1, 0]]
X0 = np.asarray(X0)
#delta_t = 10e-4
n = 100 #number of iteration n
arr = RK4(X0, n)
def kinetic(array1): # T = m*v**2/2
    K = []
    for item in array1:
        r1 = item[0]
        v1 = item[1]
        r2 = item[2]
        v2 = item[3]
        r3 = item[4]
        v3 = item[5]
        T1 = np.dot(v1, v1)/2
        T2 = np.dot(v2, v2)/2
        T3 = np.dot(v3, v3)/2
        T_tot = T1 + T2 + T3
        K.append(T_tot)
    return K
kinetic_energy = kinetic(arr)
kinetic_energy = np.asarray(kinetic_energy)

def potential(array1):
    pot = []
    U = 0
    for item in array1:
        r1 = item[0]
        v1 = item[1]
        r2 = item[2]
        v2 = item[3]
        r3 = item[4]
        v3 = item[5]
        U = (-1)*(1/np.linalg.norm(r1-r2) + 1/np.linalg.norm(r1-r3) + 1/np.linalg.norm(r2-r3))
        pot.append(U)
    return pot
potential_energy = potential(arr)
potential_energy = np.asarray(potential_energy)

E = kinetic_energy + potential_energy

plt.figure("Energy")
plt.plot(kinetic_energy, label = "K")
plt.plot(potential_energy, label = "U")
plt.plot(E, label = "E")
plt.legend()
plt.show()

def traj(array1):
    x1 = []
    x2 = []
    x3 = []
    y1 = []
    y2 = []
    y3 = []
    for item in array1:
        r1 = item[0]
        v1 = item[1]
        r2 = item[2]
        v2 = item[3]
        r3 = item[4]
        v3 = item[5]
        x1.append(r1[0])
        x2.append(r2[0])
        x3.append(r3[0])
        y1.append(r1[1])
        y2.append(r2[1])
        y3.append(r3[1])
    trajec = [x1, y1, x2, y2, x3, y3]

    return trajec

trajectory = traj(arr)
trajectory = np.asarray(trajectory)

plt.figure("Trajectory")
plt.plot(trajectory[0], trajectory[1], label = "r1")
plt.plot(trajectory[2], trajectory[3], label = "r2")
plt.plot(trajectory[4], trajectory[5], label = "r3")
plt.legend()
plt.show()

# part d
X0 = [[0.01, 0],[0, 0],[0, 1],[1, 0],[0, -1],[-1, 0]]
X0 = np.asarray(X0)
n = 200
arr = RK4(X0, n)
kinetic_energy = kinetic(arr)
kinetic_energy = np.asarray(kinetic_energy)
potential_energy = potential(arr)
potential_energy = np.asarray(potential_energy)
E = kinetic_energy + potential_energy
plt.figure("Energy2")
plt.plot(kinetic_energy, label = "K")
plt.plot(potential_energy, label = "U")
plt.plot(E, label = "E")
plt.legend()
plt.show()
trajectory = traj(arr)
trajectory = np.asarray(trajectory)
plt.figure("Trajectory2")
plt.plot(trajectory[0], trajectory[1], label = "r1")
plt.plot(trajectory[2], trajectory[3], label = "r2")
plt.plot(trajectory[4], trajectory[5], label = "r3")
plt.legend()
plt.show()

# part e
n = 2000
arr = RK4(X0, n)
kinetic_energy = kinetic(arr)
kinetic_energy = np.asarray(kinetic_energy)
potential_energy = potential(arr)
potential_energy = np.asarray(potential_energy)
E = kinetic_energy + potential_energy
plt.figure("Energy3")
plt.plot(kinetic_energy, label = "K")
plt.plot(potential_energy, label = "U")
plt.plot(E, label = "E")
plt.legend()
plt.show()
trajectory = traj(arr)
trajectory = np.asarray(trajectory)
plt.figure("Trajectory3")
xx = np.arange(-5, 5, 0.1)
plt.xticks(xx)
plt.plot(trajectory[0], trajectory[1], label = "r1")
plt.plot(trajectory[2], trajectory[3], label = "r2")
plt.plot(trajectory[4], trajectory[5], label = "r3")
plt.legend()
plt.show()


