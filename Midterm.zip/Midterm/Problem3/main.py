import math as m
import numpy as np
import matplotlib.pyplot as plt
import scipy.linalg as LA
import csv
import sys
from sympy import symbols, diff # use these two lib to make partial derivatives
from scipy.fft import fft, ifft

data_list = []
with open('data.csv','r') as data:
    d1 = csv.reader(data)
    for i in d1:
        data_list.extend(i) #each item in this list is a str, need to use float() when using
#part a
#program
arr0 = np.array(data_list)
arr = arr0.astype(np.float)
N = arr.size
#print(arr.size) #128
#F = (arr* np.cos(arr) - np.sin(arr))* 1j/(np.pi*arr**2)
F2 = np.fft.fft(arr)

P2 = abs(F2/N)
half = int(N/2)
#print(half)
P1 = P2[:half]
P1[1:] = 2*P1[1:]
Fs = 1
f = np.arange(N/2)
#print(f)
for i in range(int(N/2)):
    f[i] = f[i]/N
#print(f)

# plt.figure(1)
# plt.plot(np.real(F2), label = "real")
# plt.plot(np.imag(F2), label = "imag")
# plt.legend()
plt.figure("FFT for x")
plt.plot(f, P1)
#plt.legend()

plt.show()

c = np.zeros(N, complex)
n = np.arange(N)
#reverse
# for k in range(N):
#     c[k] = (1/N) * np.sum(arr*np.exp(-2j*np.pi*k*n/N))
#plt.plot(F)
#plt.show()

# part b
Y = np.zeros(N)
#use data_list
#print(data_list, type(data_list))
for i in range(N):
    if i < N-1:
        next = i+1
        a = data_list[i]
        b = data_list[next]
        yval = 0.5*float(a) + 0.5*float(b)
        #print(i)
        Y[i] = yval
        #print("here",Y[i])
    elif i == N-1:
        Y[i] = Y[0]
#F3 = (Y* np.cos(Y) - np.sin(Y))* 1j/(np.pi*Y**2)
F4 = np.fft.fft(Y)

P4 = abs(F4/N)
half = int(N/2)
#print(half)
P3 = P4[:half]
P3[1:] = 2*P3[1:]
Fs = 1
f2 = np.arange(N/2)
#print(f2)
for i in range(int(N/2)):
    f2[i] = f2[i]/N
#print(f2)

# plt.figure(3)
# plt.plot(np.real(F3), label = "real")
# plt.plot(np.imag(F3), label = "imag")
plt.figure("FFT for y")
plt.plot(f, P3)
#plt.legend()
plt.show()
