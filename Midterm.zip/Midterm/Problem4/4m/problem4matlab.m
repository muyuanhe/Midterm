n = 10;
A = zeros(n,n);
for row = 1:size(A, 1)
    for col = 1:size(A, 2)
        if row ~= col
            A(row,col) = (1)/(n+1);
        else
            A(row,col) = (1+1)/(n+1);
        end
    end
end
%disp(A)
logA = zeros(n, n);
I = eye(n);
%disp(I)
for k = 1:100
    logA = logA - (I - A)^k / k;
end
file1 = fopen("log(A)", "w");
%fprintf(file1, 'logA');
%fclose(file1);
writematrix(logA)
%type "LogA.txt"

%logA_ture = logm(A);

n = [10, 20, 50, 10, 200, 500, 1000, 2000];
%disp(n(1))
time = zeros(1, 8);
for i=1:8
    tic
    n1 = n(i);
    A1 = zeros(n1,n1);
    for row = 1:size(A1, 1)
        for col = 1:size(A1, 2)
             if row ~= col
                A1(row,col) = (1)/(n1+1);
            else
                A1(row,col) = (1+1)/(n1+1);
             end
        end
    end
    logA1 = zeros(n(i), n(i));
    I = eye(n(i));
    %disp(I)
    for k = 1:100
        logA1 = logA1 - (I - A1)^k / k;
    end
    time(i) = toc;
end
plot(time);

    