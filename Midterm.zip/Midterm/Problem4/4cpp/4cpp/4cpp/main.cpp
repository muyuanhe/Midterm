#include <vector>
#include <iostream>
#include <algorithm>
#include <cmath>
#include <fstream>
//#include <"Eigen/Dense"> This doesn't work
using namespace std;


int main()
{
    
    const size_t n = 10;
    int A1[n][n] {};
    for ( int i = 0; i < n; i++ )
        for ( int j = 0; j < n; j++ )
        {
            if (i != j)
            {
                A1[i][j] = 1/(n+1);
            }
            else
            {
                A1[i][j] = (1+1)/(n+1);
            }
        }
    
    int I[n][n] {};
    for ( int i = 0; i < n; i++ )
        for ( int j = 0; j < n; j++ )
        {
            if (i == j)
            {
                A1[i][j] = 1;
            }
            else
            {
                A1[i][j] = 0;
            }
        }
    int logA = 0;
    
    for(int k=0; k<100; k++)
    {
        logA += (-1) * pow((I-A1),(k+1)/(k+1)); // I know this is not right way to calculate matrix power, but my computer does not allow me to use eigen
    }
    ofstream myfile;
    myfile.open ("log(A).txt");
    myfile << logA;
    myfile.close();
        
    
    
    
    
    
    
    
    
    
    
    
 }
    
    
    
