import math as m
import numpy as np
import matplotlib.pyplot as plt
import scipy.linalg as LA
import csv
import sys
from sympy import symbols, diff # use these two lib to make partial derivatives
from scipy.fft import fft, ifft
from time import process_time
from scipy.linalg import logm, expm
from numpy.linalg import matrix_power

t1_start = process_time()
t1_stop = process_time()

# part c
#A[i,j] = (1+delta_ij)/(10+1)
n = 10
A1 = np.identity(n)
I = np.identity(n)
for row in range(len(A1)):
    for col in range(len(A1[row])):
        if row == col:
            A1[row][col] = (1+1)/(n+1)
        else:
            A1[row][col] = 1/(n+1)
#print("A1", A1)
logA = 0
for k in range(100):
    logA += (-1)* matrix_power((I-A1),(k+1)) / (k+1)
#print("logA", logA)
#print("logm", logm(A1))
#print("norm A1", LA.norm(A1))
#print(logA-logm(A1))
outF = open("myOutFile.txt", "w")
logA = logA.tolist()
for line in logA:
    #print(str(line))
    outF.write(str(line))
    outF.write("\n")
outF.close()


#part d
n = [10, 20, 50, 100, 200, 500, 1000, 2000]
run_time = []
for i in range(len(n)):
    t1_start = process_time()

    A = np.identity(n[i])
    I = np.identity(n[i])

    for row in range(len(A)):
        for col in range(len(A[row])):
            if row == col:
                A[row][col] = (1 + 1) / (n[i] + 1)
            else:
                A[row][col] = 1 / (n[i] + 1)

    logA1 = 0
    for k in range(100):
        logA1 -= matrix_power((I - A), (k + 1)) / (k + 1)
    t1_stop = process_time()
    t = t1_stop - t1_start
    run_time.append(t)

t1_stop = process_time()
est_time_list = []
#print(run_time[0])
for item in n:
    est_t = ((item/n[0]) * run_time[0])**3
    est_time_list.append(est_t)
est_time_array = np.asarray(est_time_list)
#est_2 = est_time_array
est_time_array = np.log(est_time_array)
#est_time_2 = est_time_array * est_2

#print(type(run_time))
x_axi = np.arange(len(n))
run_time = np.asarray(run_time)
run_time = np.log(run_time)
x_axi = np.log(x_axi)
#print(x_axi, run_time)
plt.figure()
plt.plot(x_axi, run_time, label = "run time")
plt.plot(x_axi, est_time_array, label = "estimated run time")
#plt.plot(x_axi, est_time_2, label = "est: O(NlogN)")
plt.ylabel("log(t)")
plt.xlabel("log(n)")
plt.legend()
plt.show()
